﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LV4
{
    public class DiscountedItem : RentableDecorator
    {
        private readonly double DiscountedItemPercentage = 0.5;
        public DiscountedItem(IRentable rentable) : base(rentable){ }
        public override double CalculatePrice()
        {
            return (1 - DiscountedItemPercentage) * base.CalculatePrice();
        }
        public override String Description
        {
            get
            {
                return "Trending: " + base.Description + " now at 50% off!";
            }
        }
    }
}
