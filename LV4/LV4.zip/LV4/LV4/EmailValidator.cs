﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LV4
{
    class EmailValidator
    {
        public bool IsValidAddress(String candidate)
        {
            if (String.IsNullOrEmpty(candidate))
            {
                return false;
            }
            return ContainsAtSign(candidate) && EndsWithCorrectWord(candidate);
        }
        private bool ContainsAtSign(String candidate)
        {
            return candidate.Contains('@');
        }
        private bool EndsWithCorrectWord(String candidate)
        {
            return (candidate.EndsWith(".com") || candidate.EndsWith(".hr")); 
        }
    }
}
