﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LV4
{
    public class RegistrationValidator : IRegistrationValidator
    {
        PasswordValidator passwordValidator;
        EmailValidator emailValidator;

        public RegistrationValidator()
        {
            this.passwordValidator = new PasswordValidator(5);
            this.emailValidator = new EmailValidator();
        }
        public bool IsUserEntryValid(UserEntry entry)
        {
            if (passwordValidator.IsValidPassword(entry.Password) == true && emailValidator.IsValidAddress(entry.Email) == true)
                return true;
            else
                return false;
        }
    }
}
