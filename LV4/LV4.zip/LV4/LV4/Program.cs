﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LV4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Zadatak2
            Dataset dataset = new Dataset("csv.txt");
            Analyzer3rdParty analyzer = new Analyzer3rdParty();
            Adapter adapter = new Adapter(analyzer);
            double[] columnAverage = adapter.CalculateAveragePerColumn(dataset);
            double[] rowAverage = adapter.CalculateAveragePerRow(dataset);
            for (int i = 0; i < columnAverage.Length; i++)
                Console.WriteLine(columnAverage[i]);
            Console.WriteLine();
            for (int i = 0; i < rowAverage.Length; i++)
                Console.WriteLine(rowAverage[i]);

            //Zadatak3
            Video video = new Video("video");
            Book book = new Book("book");
            List<IRentable> items = new List<IRentable>() { video, book };
            RentingConsolePrinter printer = new RentingConsolePrinter();
            printer.DisplayItems(items);
            printer.PrintTotalPrice(items);

            //Zadatak4
            HotItem hotVideo = new HotItem(new Video("video2"));
            HotItem hotBook = new HotItem(new Book("book2"));
            items.Add(hotVideo);
            items.Add(hotBook);
            printer.DisplayItems(items);
            printer.PrintTotalPrice(items);

            //Zadatak5
            List<IRentable> flashSale = new List<IRentable>();
            for (int i = 0; i < items.Count; i++)
                flashSale.Add(new DiscountedItem(items[i]));
            printer.DisplayItems(flashSale);
            printer.PrintTotalPrice(flashSale);

            //Zadatak6
            PasswordValidator passwordValidator = new PasswordValidator(5);
            EmailValidator emailValidator = new EmailValidator();
            if (passwordValidator.IsValidPassword("abc") == true)
                Console.WriteLine("Lozinka valjana");
            else
                Console.WriteLine("Lozinka nije valjana");
            if (emailValidator.IsValidAddress("fahf@adfa.com") == true)
                Console.WriteLine("Email valjan");
            else
                Console.WriteLine("Email nije valjan");

            //Zadatak7
            RegistrationValidator validator = new RegistrationValidator();
            UserEntry entry = UserEntry.ReadUserFromConsole();
            while (validator.IsUserEntryValid(entry) == false)
                UserEntry.ReadUserFromConsole();
        }
    }
}
